
import java.io.*;
import java.net.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Client extends Application {

    // IO streams

    ObjectOutputStream toServer = null;
    DataInputStream fromServer = null;

    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        //Vbox to hold all labels/TextFields
        VBox vb1 = new VBox();
        
        //Create all borderpanels and adjust settings
        BorderPane bp1 = new BorderPane();
        BorderPane bp2 = new BorderPane();
        BorderPane bp3 = new BorderPane();
        BorderPane bp4 = new BorderPane();
        bp1.setPadding(new Insets(5, 5, 5, 5));
        bp1.setStyle("-fx-border-color: green");
        bp1.setLeft(new Label("Enter a name: "));
        
        bp2.setPadding(new Insets(5, 5, 5, 5));
        bp2.setStyle("-fx-border-color: green");
        bp2.setLeft(new Label("Enter a age: "));
        
        bp3.setPadding(new Insets(5, 5, 5, 5));
        bp3.setStyle("-fx-border-color: green");
        bp3.setLeft(new Label("Enter a weight: "));
        
        bp4.setPadding(new Insets(5, 5, 5, 5));
        bp4.setStyle("-fx-border-color: green");
        bp4.setLeft(new Label("Enter a height: "));

        //Create all textFields
        TextField tf1 = new TextField();
        tf1.setAlignment(Pos.BOTTOM_RIGHT);
        bp1.setCenter(tf1);
        TextField tf2 = new TextField();
        tf2.setAlignment(Pos.BOTTOM_RIGHT);
        bp2.setCenter(tf2);
        TextField tf3 = new TextField();
        tf3.setAlignment(Pos.BOTTOM_RIGHT);
        bp3.setCenter(tf3);
        TextField tf4 = new TextField();
        tf4.setAlignment(Pos.BOTTOM_RIGHT);
        bp4.setCenter(tf4);
        
        //Button object ro allow for Event Handling
        Button b1 = new Button("Calculate BMI");
        vb1.setAlignment(Pos.CENTER);
        
        //Add all the borderpanel objects to Vbox
        vb1.getChildren().addAll(bp1, bp2, bp3, bp4, b1);

        BorderPane mainPane = new BorderPane();
        
        // Text area to display contents
        TextArea ta = new TextArea();
        mainPane.setCenter(new ScrollPane(ta));
        mainPane.setTop(vb1);

        // Create a scene and place it in the stage
        Scene scene = new Scene(mainPane, 450, 300);
        primaryStage.setTitle("Client"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage

        //Button Event Listener
        b1.setOnAction(e -> {
            try {
                
                // Create a socket to connect to the server
                Socket socket = new Socket("localhost", 8000);


                // Create an input stream to receive data from the server
                fromServer = new DataInputStream(socket.getInputStream());

                // Create an output stream to send Object data to the server
                toServer = new ObjectOutputStream(socket.getOutputStream());
            
                // Get the name, age, weight & height from textfields
                String name = tf1.getText();
                int age = Integer.parseInt(tf2.getText().trim());
                double weight = Double.parseDouble(tf3.getText().trim());
                double height = Double.parseDouble(tf4.getText().trim());

                //Create person object to send to server
                Person p1 = new Person(name, age, weight, height);

                //Write object to server
                toServer.writeObject(p1);
                
                // Get BMI from the server
                double BMI = fromServer.readDouble();
                

                // Display to the text area
                ta.appendText("Name is " + name + "\n");
                ta.appendText("Age is " + age + "\n");
                ta.appendText("Weight is " + weight + "\n");
                ta.appendText("Height is " + height + "\n");
                ta.appendText("BMI received from the server is "
                        + BMI + '\n');
            } catch (IOException ex) {
                System.err.println(ex);
            }
        });
    }

    /**
     * The main method is only needed for the IDE with limited JavaFX support.
     * Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
