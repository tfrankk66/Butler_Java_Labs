package butler_java2_lab1_payroll;

public class Payroll {
    
    final int ARRAYSIZE = 7;
    int employeeId[] = {5658845, 4520125, 7895122, 8777541, 8451277, 1302850, 7580489};
    int hours[] = new int[ARRAYSIZE];
    int payrate[] = new int[ARRAYSIZE];
    int wages[] = new int[ARRAYSIZE];

    public int getEmployeeId(int a) {
        return employeeId[a];
    }

    
    public int getHours(int a) {
        return hours[a];
    }
    public void setHours(int a, int b) {
        hours[a] = b;
    }

    
    public int getPayrate(int a) {
        return payrate[a];
    }
    public void setPayrate(int a, int b) {
        payrate[a] = b;
    }
    
    
    public int wage(int a){
        int w = 0;
        
        w = hours[a] * payrate[a];
        
        return w;
    }
    
}
