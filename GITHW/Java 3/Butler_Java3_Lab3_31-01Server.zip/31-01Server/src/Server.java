
import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class Server extends Application {

    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        // Text area for displaying contents
        TextArea ta = new TextArea();

        // Create a scene and place it in the stage
        Scene scene = new Scene(new ScrollPane(ta), 450, 200);
        primaryStage.setTitle("Server"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage

        new Thread(() -> {
            try {
                // Create a server socket
                ServerSocket serverSocket = new ServerSocket(8000);
                Platform.runLater(()
                        -> ta.appendText("Server started at " + new Date() + '\n'));

                // Listen for a connection request
                Socket socket = serverSocket.accept();

                // Create data input and output streams
                ObjectInputStream inputFromClient = new ObjectInputStream(
                        socket.getInputStream());
                DataOutputStream outputToClient = new DataOutputStream(
                        socket.getOutputStream());

                while (true) {
                    
                    //Read in object data from client
                    Person p1 = (Person) inputFromClient.readObject();
                    
                    //Create BMI object to calculate BMI
                    BMI bmicalc = new BMI(p1.getName(), p1.getAge(), p1.getWeight(), p1.getHeight());
                    
                    // Compute BMI
                    double BMI = bmicalc.getBMI();

                    // Send BMI back to the client
                    outputToClient.writeDouble(BMI);

                    Platform.runLater(() -> {
                        ta.appendText("Name received from client: "
                                + p1.getName() + '\n');
                        ta.appendText("Age received from client: "
                                + p1.getAge() + '\n');
                        ta.appendText("Weight received from client: "
                                + p1.getWeight() + '\n');
                        ta.appendText("Height received from client: "
                                + p1.getHeight() + '\n');
                        ta.appendText("BMI is: " + BMI + '\n');
                    });
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();
    }

    /**
     * The main method is only needed for the IDE with limited JavaFX support.
     * Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
