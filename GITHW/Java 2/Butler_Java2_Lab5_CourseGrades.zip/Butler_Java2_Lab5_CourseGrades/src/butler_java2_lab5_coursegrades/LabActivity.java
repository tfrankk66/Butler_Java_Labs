package butler_java2_lab5_coursegrades;

public class LabActivity extends GradedActivity{
    
    public LabActivity(double s){
        setScore(s);
    }
    
}
