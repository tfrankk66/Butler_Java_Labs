package butler_java2_lab1_population;

import java.util.Scanner;
public class Butler_Java2_Lab1_Population {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        double orgS = 0;
        double adp = 0;
        double days = 0;
        double temp = 0;
        
        System.out.print("Please enter the starting number of organisms: ");
        orgS = input.nextDouble();
        
        while(orgS < 2){
            System.out.print("Invalid Number! Please enter the starting number of organisms greater than 2: ");
            orgS = input.nextDouble();
        }
        
        System.out.print("Please enter the average daily population increase as a percentage (EX: 0.5): ");
        adp = input.nextDouble();
        
        while(adp < 0){
            System.out.print("Invalid Number! Please enter the average daily population increase as a percentage greater than 0 (EX: 0.5): ");
            adp = input.nextDouble();
        }
        
        System.out.print("Please enter the number of days for multiplying: ");
        days = input.nextDouble();
        System.out.print("\n");
        
        while(days < 1){
            System.out.print("Invalid Number! Please enter the number of days for multiplying greater than 1: ");
            days = input.nextDouble();
        }
        
        for(int i = 0; i < days; i++){
            
            temp = orgS * adp;
            orgS = orgS += temp;
            System.out.println("Day " + (i + 1));
            System.out.println("Population: " + orgS + "\n");
        }
    }
    
}
