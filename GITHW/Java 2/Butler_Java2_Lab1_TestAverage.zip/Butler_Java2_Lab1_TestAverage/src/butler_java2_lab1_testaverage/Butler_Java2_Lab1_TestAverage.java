package butler_java2_lab1_testaverage;
import java.util.Scanner;

public class Butler_Java2_Lab1_TestAverage {

    public static void main(String[] args) {
        double test1, test2, test3, test4, test5 = 0;
        Scanner input = new Scanner(System.in);
        
        System.out.print("Please enter a grade for Test #1: ");
        test1 = input.nextDouble();
        System.out.print("\n");
        
        System.out.print("Please enter a grade for Test #2: ");
        test2 = input.nextDouble();
        System.out.print("\n");
        
        System.out.print("Please enter a grade for Test #3: ");
        test3 = input.nextDouble();
        System.out.print("\n");
        
        System.out.print("Please enter a grade for Test #4: ");
        test4 = input.nextDouble();
        System.out.print("\n");
        
        System.out.print("Please enter a grade for Test #5: ");
        test5 = input.nextDouble();
        System.out.print("\n");
        
        System.out.println("Letter Grade for Test 1: " + determineGrade(test1));
        System.out.println("Letter Grade for Test 2: " + determineGrade(test2));
        System.out.println("Letter Grade for Test 3: " + determineGrade(test3));
        System.out.println("Letter Grade for Test 4: " + determineGrade(test4));
        System.out.println("Letter Grade for Test 5: " + determineGrade(test5));
        
        System.out.println("\nAverage for the five test scores: " + calcAverage(test1, test2, test3, test4, test5));
        System.out.println("Letter grade for average test score: " + determineGrade(calcAverage(test1, test2, test3, test4, test5)));
        
        
        
    }
    
    public static double calcAverage(double t1, double t2, double t3, double t4, double t5){
        double avg = 0;
        
        avg = (t1 + t2 + t3 + t4 + t5) / 5;
        
        return avg;
    }
    
    public static char determineGrade(double t){
        char grade = 'M';
        double temp = t;
        
        if(temp < 60){
            grade = 'F';
        }
        else if(temp >= 60 && temp <= 69){
            grade = 'D';
        }
        else if(temp >= 70 && temp <= 79){
            grade = 'C';
        }
        else if(temp >= 80 && temp <= 89){
            grade = 'B';
        }
        else if(temp >= 90 && temp <= 100){
            grade = 'A';
        }
        
        return grade;
    }
    
}
