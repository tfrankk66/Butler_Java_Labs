package butler_java2_lab1_bankcharge;

import java.util.Scanner;
public class Butler_Java2_Lab1_BankCharge {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        int checkNum = 0;
        double checkAm = 0;
        double checkFee = 0;
        final int baseFee = 10;
        
        System.out.print("Please enter the amount of checks written for the current month.  ");
        checkAm = in.nextInt();
        
        if(checkAm < 20){
            checkFee = checkAm *= .10;
        }
        else if(checkAm >= 20 && checkAm <= 39){
            checkFee = checkAm *= .08;
        }
        else if(checkAm >= 40 && checkAm <= 59){
            checkFee = checkAm *= .06;
        }
        else if(checkAm >= 60){
            checkFee = checkAm *= .04;
        }
        
        System.out.println("\nCHARGE TOTAL");
        System.out.println("-------------");
        System.out.println("Base Charge: $" + baseFee);
        System.out.println("Check Fee: $" + checkFee);
        System.out.println("Total Charge: $" + (baseFee + checkFee));
        
        
      
        
        
        
    }
    
}
