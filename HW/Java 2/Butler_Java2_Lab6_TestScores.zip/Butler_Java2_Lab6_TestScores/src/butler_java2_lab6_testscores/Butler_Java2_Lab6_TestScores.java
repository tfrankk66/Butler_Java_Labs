package butler_java2_lab6_testscores;

public class Butler_Java2_Lab6_TestScores {

    public static void main(String[] args) {
        double[] ts = {67, 78, 89, -1};
        
        TestScores t = new TestScores(ts);
    }
    
    
    
}
