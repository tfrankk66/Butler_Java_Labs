package butler_java2_lab1_payroll;

import java.util.Scanner;

public class Butler_Java2_Lab1_Payroll {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Payroll p = new Payroll();
        
        
        for(int i = 0; i < 7; i++){
            System.out.print("Please enter the hours for Employee ID# " + p.getEmployeeId(i) + ": ");
            p.setHours(i, input.nextInt());
            
            while(p.getHours(i) < 0){
                System.out.print("INVALID NUMBER! Please enter the hours for Employee ID# " + p.getEmployeeId(i) + " that is greater than 1: ");
                p.setHours(i, input.nextInt());
            }
            
            System.out.print("Please enter the pay rate for Employee ID# " + p.getEmployeeId(i) + ": ");
            p.setPayrate(i, input.nextInt());
            
            while(p.getPayrate(i) < 6){
                System.out.print("INVALID NUMBER! Please enter the pay rate for Employee ID# " + p.getEmployeeId(i) + " that is greater than 6: ");
                p.setPayrate(i, input.nextInt());
            }
        }
    
        System.out.println("\n\nEmployee ID   Gross Pay");
        System.out.println("----------------------\n");
        
        for(int i = 0; i < 7; i++){
            System.out.println(p.getEmployeeId(i) + "        $ " + p.wage(i));
        }
    }   
}
