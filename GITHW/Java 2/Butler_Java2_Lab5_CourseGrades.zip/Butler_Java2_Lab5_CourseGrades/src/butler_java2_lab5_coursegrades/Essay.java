package butler_java2_lab5_coursegrades;

public class Essay extends GradedActivity{
    
    public Essay(double s){
        setScore(s);
    }
}
